def collision_warning(object_count):

    if object_count >= 5:

        return "HIGH RISK"

    elif object_count >= 2:

        return "MEDIUM RISK"

    else:

        return "LOW RISK"



    risk = "LOW RISK"

    closest_object_area = 0

    for result in object_count:

        boxes = result.boxes

        for box in boxes:

            ####################################
            # GET BOUNDING BOX COORDINATES
            ####################################

            x1, y1, x2, y2 = box.xyxy[0]

            width = x2 - x1
            height = y2 - y1

            area = width * height

            ####################################
            # FIND CLOSEST OBJECT
            ####################################

            if area > closest_object_area:

                closest_object_area = area

    ####################################
    # RISK ANALYSIS
    ####################################

    # Very close object
    if closest_object_area > 150000:

        risk = "HIGH RISK"

    # Medium distance
    elif closest_object_area > 50000:

        risk = "MEDIUM RISK"

    # Far objects
    else:

        risk = "LOW RISK"

    return risk