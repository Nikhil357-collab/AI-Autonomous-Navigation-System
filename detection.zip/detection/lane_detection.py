import cv2
import numpy as np

def region_of_interest(img):

    height = img.shape[0]

    polygons = np.array([
        [
            (100, height),
            (550, 250),
            (750, 250),
            (1200, height)
        ]
    ])

    mask = np.zeros_like(img)

    cv2.fillPoly(mask, polygons, 255)

    masked_image = cv2.bitwise_and(img, mask)

    return masked_image


def detect_lanes(frame):

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    blur = cv2.GaussianBlur(gray, (5, 5), 0)

    edges = cv2.Canny(blur, 50, 150)

    cropped_edges = region_of_interest(edges)

    lines = cv2.HoughLinesP(
        cropped_edges,
        2,
        np.pi / 180,
        100,
        np.array([]),
        minLineLength=40,
        maxLineGap=5
    )

    lane_center = frame.shape[1] // 2

    if lines is not None:

        left_lines = []
        right_lines = []

        for line in lines:

            x1, y1, x2, y2 = line[0]

            slope = 0

            if x2 - x1 != 0:
                slope = (y2 - y1) / (x2 - x1)

            # Ignore horizontal noise
            if abs(slope) < 0.5:
                continue

            # LEFT LANE
            if slope < 0:
                left_lines.append(line)

            # RIGHT LANE
            else:
                right_lines.append(line)

            cv2.line(
                frame,
                (x1, y1),
                (x2, y2),
                (0, 255, 0),
                5
            )

        # Approximate lane center
        if len(left_lines) > 0 and len(right_lines) > 0:

            left_x = left_lines[0][0][0]
            right_x = right_lines[0][0][2]

            lane_center = (left_x + right_x) // 2

    return frame, lane_center