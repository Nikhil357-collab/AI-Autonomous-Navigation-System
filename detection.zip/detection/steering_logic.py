def navigation_decision(
    lane_center,
    frame_center,
    object_count,
):
    deviation = lane_center - frame_center

    ####################################
    # DEFAULT VALUES
    ####################################

    steering = "MAINTAIN LANE"

    speed = "NORMAL SPEED"

    horn = "OFF"

    ####################################
    # STEERING LOGIC
    
    ####################################

    # Slight Left
    if deviation < -50 and deviation > -150:

        steering = "MOVE SLIGHT LEFT"

    # Sharp Left
    elif deviation <= -150:

        steering = "TURN SHARP LEFT"

    # Slight Right
    elif deviation > 50 and deviation < 150:

        steering = "MOVE SLIGHT RIGHT"

    # Sharp Right
    elif deviation >= 150:

        steering = "TURN SHARP RIGHT"

    ####################################
    # SPEED CONTROL
    ####################################

    if object_count >= 15:

        speed = "SLOW DOWN"

    if object_count >= 25:

        speed = "VERY SLOW"

    ####################################
    # HORN WARNING
    ####################################

    if object_count >= 20:

        horn = "HORN WARNING"

    ####################################
    # EMERGENCY
    ####################################

    if object_count >= 30:

        steering = "EMERGENCY STOP"

        speed = "STOP"

        horn = "EMERGENCY HORN"

    return steering, speed, horn