import cv2

def draw_dashboard(
    frame,
    status,
    object_count,
    fps,
    steering,
    speed,
    horn,
    risk
):

    ####################################
    # BACKGROUND PANEL
    ####################################

    cv2.rectangle(
        frame,
        (10, 10),
        (550, 330),
        (40, 40, 40),
        -1
    )

    ####################################
    # AI STATUS
    ####################################

    cv2.putText(
        frame,
        f"AI STATUS: {status}",
        (20, 40),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (0, 255, 0),
        2
    )

    ####################################
    # OBJECT COUNT
    ####################################

    cv2.putText(
        frame,
        f"OBJECTS DETECTED: {object_count}",
        (20, 80),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (255, 255, 0),
        2
    )

    ####################################
    # NAVIGATION
    ####################################

    cv2.putText(
        frame,
        f"NAVIGATION: {steering}",
        (20, 120),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (0, 255, 255),
        2
    )

    ####################################
    # SPEED CONTROL
    ####################################

    cv2.putText(
        frame,
        f"SPEED CONTROL: {speed}",
        (20, 160),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (255, 165, 0),
        2
    )

    ####################################
    # HORN STATUS
    ####################################

    cv2.putText(
        frame,
        f"HORN STATUS: {horn}",
        (20, 200),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (0, 0, 255),
        2
    )

    ####################################
    # COLLISION RISK
    ####################################

    cv2.putText(
        frame,
        f"COLLISION RISK: {risk}",
        (20, 240),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (255, 0, 255),
        2
    )

    ####################################
    # FPS
    ####################################

    cv2.putText(
        frame,
        f"FPS: {fps}",
        (20, 280),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (255, 255, 255),
        2
    )

    return frame