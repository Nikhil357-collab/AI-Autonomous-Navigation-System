from ultralytics import YOLO

model = YOLO("AI_Based_Navigation_System/yolov8n.pt")

def detect_objects(frame):

    results = model(frame)

    annotated_frame = results[0].plot()

    object_count = 0

    for result in results:
        object_count += len(result.boxes)

    return annotated_frame, object_count